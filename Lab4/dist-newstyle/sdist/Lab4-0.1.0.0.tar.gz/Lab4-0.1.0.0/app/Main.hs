module Main (main) where
import Text.HTML.TagSoup
import Data.List (find, nub)
import Text.Read (readMaybe)
import System.IO
import Data.Maybe (fromMaybe, mapMaybe, listToMaybe, catMaybes)
-- Define data types for publications
data PublicationType = Book | Article | ConferencePaper deriving (Eq, Show)
data Publication = Publication {
  pubType :: PublicationType,
  pubAuthors :: [String],
  pubTitle :: String,
  pubCity :: Maybe String,
  pubPublisher :: Maybe String,
  pubJournal :: Maybe String,
  pubYear :: Maybe Int,
  pubJournalIssue :: Maybe Int,
  pubPages :: Maybe String,
  pubConference :: Maybe String
} deriving (Eq, Show)

-- Define a sample database of publications
publications :: [Publication]
publications = [
  Publication Book ["John Doe"] "My Book" (Just "New York") (Just "ABC Publishing") (Nothing) (Just 2021) Nothing Nothing Nothing,
  Publication Article ["John Doe", "Jane Smith"] "My Article" (Nothing) (Nothing) (Just "Journal of Science") (Just 2020) (Just 1) (Just "10-20") Nothing,
  Publication ConferencePaper ["Jane Smith"] "My Conference Paper" (Just "Paris") (Nothing) (Nothing) (Just 2019) Nothing (Just "100-110") (Just "Conference on Research")
 ]

instance Read PublicationType where
  readsPrec _ "Book" = [(Book, "")]
  readsPrec _ "Article" = [(Article, "")]
  readsPrec _ "ConferencePaper" = [(ConferencePaper, "")]
  readsPrec _ _ = []

-- Read a publication from a string
readPublication :: String -> Publication
readPublication line =
  let
    (pubTypeStr : authorsStr : title : city : pub : journal : year : issue : pages : conf) = words line
    pubType = read pubTypeStr
    authors = words authorsStr
    city' = if city == "-" then Nothing else Just city
    pub' = if pub == "-" then Nothing else Just pub
    journal' = if journal == "-" then Nothing else Just journal
    year' = readMaybe year
    issue' = readMaybe issue
    pages' = if pages == "-" then Nothing else Just pages
    conf' = if null conf then Nothing else Just (unwords conf)
  in
    Publication pubType authors title city' pub' journal' year' issue' pages' conf'

-- Read a list of publications from a file
readPublications :: FilePath -> IO [Publication]
readPublications filePath = do
  content <- readFile filePath
  let publications = map readPublication (lines content)
  return publications

-- Write a list of publications to a file
writePublications :: FilePath -> [Publication] -> IO ()
writePublications filePath pubs = do
  handle <- openFile filePath WriteMode
  hPutStr handle (unlines (map show pubs))
  hClose handle

writePublicationsToHtml :: String -> [Publication] -> IO ()
writePublicationsToHtml filename pubs = do
  let html = "<html>\n<head>\n<title>Publications</title>\n</head>\n<body>\n" ++
             (concat $ map publicationToHtml pubs) ++
             "</body>\n</html>"
  writeFile filename html

publicationToHtml :: Publication -> String
publicationToHtml (Publication pubType authors title city publisher journal year issue pages conference) =
  "<p><b>" ++ show pubType ++ "</b><br>" ++
  "Authors: " ++ intercalate ", " authors ++ "<br>" ++
  "Title: " ++ title ++ "<br>" ++
  (maybe "" (\c -> "City: " ++ c ++ "<br>") city) ++
  (maybe "" (\p -> "Publisher: " ++ p ++ "<br>") publisher) ++
  (maybe "" (\j -> "Journal: " ++ j ++ "<br>") journal) ++
  (maybe "" (\y -> "Year: " ++ show y ++ "<br>") year) ++
  (maybe "" (\i -> "Issue: " ++ show i ++ "<br>") issue) ++
  (maybe "" (\p -> "Pages: " ++ p ++ "<br>") pages) ++
  (maybe "" (\c -> "Conference: " ++ c ++ "<br>") conference) ++
  "</p>"


readPublicationsFromHtml :: String -> IO [Publication]
readPublicationsFromHtml filename = do
  html <- readFile filename
  let tags = parseTags html
      pubTags = filter (\t -> isTagOpenName t "p") tags
  return $ map htmlToPublication pubTags

htmlToPublication :: [Tag String] -> Publication
htmlToPublication tags =
  let pubTypeTag = head $ filter (\t -> isTagText t && not (null (trim (fromTagText t)))) tags
      pubTypeStr = trim (fromTagText pubTypeTag)
      pubType = read pubTypeStr
      authorTags = filter (\t -> isTagText t && not (null (trim (fromTagText t)))) $ takeWhile (not . isTagCloseName "p") $ tail tags
      authors = words $ concatMap (trim . fromTagText) authorTags
      (titleTag : restTags) = dropWhile (not . isTagCloseName "b") $ tail tags
      title = trim $ concatMap (trim . fromTagText) $ takeWhile (not . isTagCloseName "p") restTags
      (cityTag : publisherTag : journalTag : yearTag : issueTag : pagesTag : conferenceTag : _) = filter (\t -> isTagOpenName t "b") restTags
      city' = trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== cityTag)) $ restTags
      pub' = trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== publisherTag)) $ restTags
      journal' = trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== journalTag)) $ restTags
      year' = read $ trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== yearTag)) $ restTags
      issue' = read $ trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== issueTag)) $ restTags
      pages' = trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== pagesTag)) $ restTags
      conf' = trim $ fromTagText $ head $ dropWhile (not . isTagText) $ tail $ dropWhile (not . (== conferenceTag)) $ restTags
  in
      Publication pubType authors title city' pub' journal' year' issue' pages' conf'



-- Define functions to perform operations on the database

-- 2.1 Determine the type of a publication given its title
getTypeByTitle :: String -> [Publication] -> Maybe PublicationType
getTypeByTitle title pubs = pubType <$> find (\p -> pubTitle p == title) pubs

-- 2.2 Find all publications of a given author
getPublicationsByAuthor :: String -> [Publication] -> [Publication]
getPublicationsByAuthor author pubs = filter (\p -> elem author (pubAuthors p)) pubs

-- 2.3 Find all publications of a given author where they are the only author
getSoloPublicationsByAuthor :: String -> [Publication] -> [Publication]
getSoloPublicationsByAuthor author pubs = filter (\p -> length (pubAuthors p) == 1 && head (pubAuthors p) == author) pubs

-- 2.4 Find all unique publishers, journals, and conference names in the database
getPublishers :: [Publication] -> [String]
getPublishers pubs = nub $ catMaybes (pubPublisher <$> pubs)

getJournals :: [Publication] -> [String]
getJournals pubs = nub $ catMaybes (pubJournal <$> pubs)

getConferences :: [Publication] -> [String]
getConferences pubs = nub $ catMaybes (pubConference <$> pubs)

-- 2.5 Get statistics on the number of publications of each type in the database
getPublicationTypeCounts :: [Publication] -> [(PublicationType, Int)]
getPublicationTypeCounts pubs = [(t, length $ filter (\p -> pubType p == t) pubs) | t <- [Book, Article, ConferencePaper]]

printHelp :: IO ()
printHelp = putStrLn
  "Usage: publications [DBNAME] [-c|--command COMMANDNAME [ARGS]]\n\
  \       publications -h: display this help message\n\
  \       publications -statistics: display statistics on the number of publications of each type in the database\n\
  \       publications -publishers: display all unique publishers names in the database\n\
  \       publications -journals: display all unique journals names in the database\n\
  \       publications -conferences: display all unique conference names in the database"

loop :: IO ()
loop = do
  input <- getLine
  case words input of
    ["publications", "-statistics"] -> do
      writePublications "text.txt" publications
      writePublicationsToHtml "text.txt" publications
      mapM_ print publications
      loop
    ["publications", "-publishers"] -> do
      print(getPublishers publications)
      loop
    ["publications", "-journals"] -> do
      print(getJournals publications)
      loop
    ["publications", "-conferences"] -> do
      print(getConferences publications)
      loop
    ["publications", dbname, "-c", cmd, args] -> do
      putStrLn ("Running command " ++ cmd ++ " with arguments " ++ unwords [args] ++ " on database " ++ dbname)
      loop
    ["publications", "-h"] -> printHelp >> loop
    ["quit"] -> return ()
    _ -> do
      putStrLn "Invalid command. Type 'publications -h' for help."
      loop

main :: IO ()
main = do
  putStrLn "Enter some text or type 'quit' to end the loop:"
  loop